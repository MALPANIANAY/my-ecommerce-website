<?php
// Heading
$_['heading_title'] = 'Total Customers';

// Text
$_['text_view'] = 'View more...';