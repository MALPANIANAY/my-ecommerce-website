<?php
// Text
$_['text_footer'] 	= '<a href="http://www.platformx.tech">PlatformX Solutions</a>';